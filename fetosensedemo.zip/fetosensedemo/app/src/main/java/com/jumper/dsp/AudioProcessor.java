package com.jumper.dsp;

public interface AudioProcessor {
    boolean process(AudioEvent var1);
    void processingFinished();
}
