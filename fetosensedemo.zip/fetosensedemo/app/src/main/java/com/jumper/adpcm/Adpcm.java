package com.jumper.adpcm;

public class Adpcm {

    static {
        System.loadLibrary("bluedecode");
    }

    public static native int decode(byte[] inArr, byte[] outArr, int ratio, float opRate);

    public static native int decodec(byte[] inArr, byte[] outArr, int ratio, float opRate);

}
